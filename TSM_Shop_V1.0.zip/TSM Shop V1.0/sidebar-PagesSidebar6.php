<?php
/**
 * @package WordPress
 * @subpackage TSM-SHOP
 */
if ( !defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>

<?php
	global $tsm_shop_options;
	$sidebar_position = ( $tsm_shop_options['pages_sidebar_6'] == 'left' ) ? 'grid_8 pull_16 sidebar-box' : 'grid_8';
?>
	<div id="sidebar" class="<?php echo $sidebar_position; ?>">
	    <div id="sidebarSubnav">
<?php           tsm_shop_sidebar_top(); ?>

<?php		    // Widgetized sidebar
		    if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('PagesSidebar6') ) : ?>

			<div class="custom-formatting">
			    <h3><?php esc_html_e('About This Sidebar', 'tsm_shop'); ?></h3>
			    <ul>
				<?php _e("To edit this sidebar, go to admin backend's <strong><em>Appearance -> Widgets</em></strong> and place widgets into the <strong><em>Pages Sidebar 6</em></strong> Widget Area", 'tsm_shop'); ?>
			    </ul>
			</div>

<?php		    endif; ?>
                
<?php           tsm_shop_sidebar_bottom(); ?>
	    </div>
	    <!-- end sidebarSubnav -->
	</div>
	<!-- end sidebar -->


