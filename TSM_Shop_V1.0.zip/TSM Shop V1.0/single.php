<?php
/**
 * @package WordPress
 * @subpackage TSM-SHOP
 */
if ( !defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $tsm_shop_options;

// construct an array of portfolio categories
$portfolio_categories_array = $tsm_shop_options['portfolio_categories'];

if ( $portfolio_categories_array != "" && post_is_in_category_or_descendants( $portfolio_categories_array ) ) :
    // Test if this Post is assigned to the Portfolio category or any descendant and switch the single's template accordingly
    include 'single-Portfolio.php';
else : // Continue with normal Loop (Blog category)

    get_header();

    $content_position = ( $tsm_shop_options['blog_sidebar'] == 'left' ) ? 'grid_16 push_8' : 'grid_16';
    if ( $tsm_shop_options['remove_single_sidebar'] == 'yes' ) $content_position = 'grid_24';
?>
    <div id="content-container" class="container_24">
	<div id="main-content" class="<?php echo $content_position; ?>">
	    <div class="main-content-padding">
<?php           tsm_shop_main_content_top( is_front_page() ); ?>
<?php		if (have_posts()) :
		    while (have_posts()) : the_post(); ?>
			<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
<?php                       tsm_shop_single_post_entry_before(); ?>
                            <div class="entry">
<?php                           tsm_shop_single_post_entry_top();

                                the_content(__('<p class="serif">Read the rest of this entry &raquo;</p>', 'tsm_shop')); ?>
                                
<?php                           tsm_shop_single_post_entry_bottom(); ?>
			    </div>
<?php                       tsm_shop_single_post_entry_after(); ?>
			</div>
<?php			comments_template();
		    endwhile; else: ?>
			<p><?php esc_html_e("Sorry, no posts matched your criteria.", 'tsm_shop'); ?></p>
<?php		endif; ?>
<?php           tsm_shop_main_content_bottom(); ?>
	    </div><!-- end main-content-padding -->
	</div><!-- end main-content -->
<?php
	if( ( !$tsm_shop_options['remove_single_sidebar'] == 'yes' ) && sidebar_exist('BlogSidebar') ) { get_sidebar('BlogSidebar'); }
?>
    </div><!-- end content-container -->
<?php
endif; // end normal Loop ?>

<div class="clear"></div>

<?php

get_footer(); 


