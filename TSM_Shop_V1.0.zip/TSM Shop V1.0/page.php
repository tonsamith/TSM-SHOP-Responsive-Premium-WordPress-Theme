<?php
/**
 * @package WordPress
 * @subpackage TSM-SHOP
 */
if ( !defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header();

$content_position = ( $tsm_shop_options['pages_sidebar'] == 'left' ) ? 'grid_16 push_8' : 'grid_16';
if ( $tsm_shop_options['remove_default_page_sidebar'] == 'yes' ) $content_position = 'grid_24';
?>

<div id="content-container" class="container_24">
    <div id="main-content" class="<?php echo $content_position; ?>">
	<div class="main-content-padding">
<?php       tsm_shop_main_content_top( is_front_page() ); ?>
<?php	    if (have_posts()) : while (have_posts()) : the_post(); ?>
		<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
<?php               tsm_shop_entry_before(); ?>
		    <div class="entry">
<?php                   tsm_shop_entry_top(); ?>
<?php			the_content(__('<p class="serif">Read the rest of this page &raquo;</p>', 'tsm_shop')); ?>
<?php                   tsm_shop_entry_bottom(); ?>
		    </div>
<?php               tsm_shop_entry_after(); ?>
		</div>
<?php		( $tsm_shop_options['show_comments_on_pages'] == 'yes' ) ? comments_template() : '';
	    endwhile; endif; ?>
	    <div class="clear"></div>
<?php       tsm_shop_main_content_bottom(); ?>
	</div><!-- end main-content-padding -->
    </div><!-- end main-content -->

<?php	if( !$tsm_shop_options['remove_default_page_sidebar'] == 'yes'  ) { get_sidebar(); } ?>
</div><!-- end content-container -->

<div class="clear"></div>

<?php

get_footer();



