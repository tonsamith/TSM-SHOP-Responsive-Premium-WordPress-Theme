<?php 
if ( !defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

  
function tsm_shop_add_icon_fonts_button() {

    // the title of the modal lightbox
    $title = esc_attr__( 'TSM-SHOP: Select an Icon Font', 'tsm_shop' );
    
    // the icon for the button
    $icon_img = '<img src="' . get_template_directory_uri() . '/scripts/admin/icon-fonts/check-square.png" alt="check-square" width="18" height="18" />';

    //the container id where all the popup content will be stored
    $container_id = 'tsm_shop_icon_fonts_popup_container';

    $select_icon_font_link   = '/?TB_inline&amp;width=753&amp;height=850&amp;inlineId=' . $container_id;

    // construct the thickbox button link
    $thickbox_popup_link = '<a '
            . 'href="' . esc_url( $select_icon_font_link ) . '" '
            . 'class="thickbox button tsm-shop-icon-font-button" '
            . 'title="' . $title . '">'
            //. '<span class="fa fa-check-square-o"></span> Add Icon</a>';
            . '<span class="tsm-shop-icon-fonts-btn-img">' . $icon_img . '</span> Add Icon</a>';

    echo $thickbox_popup_link;
}
add_action('media_buttons', 'tsm_shop_add_icon_fonts_button', 12);


// The content below will be shown in the inline modal (Thickbox)
function tsm_shop_icon_fonts_popup_content() { ?>

    <div id="tsm_shop_icon_fonts_popup_container" style="display:none;">

<?php 

        function tsm_shop_add_icon_select_option() {
            /* Include the Font Awesome array, if Font Awesome is enabled of course */
            global $tsm_shop_font_awesome_options;
            $tsm_shop_fa_icons = '';
            if ( ! $tsm_shop_font_awesome_options['tsm_shop_disable_font_awesome'] ) {
                include( get_template_directory() . '/styles/common-css/font-awesome/tsm-shop-font-awesome-icons.php' );
                $tsm_shop_fa_icons = tsm_shop_fa_icons();
            }
            $tsm_shop_fontello_icons = ( tsm_shop_is_fontello_installed() ) ? tsm_shop_get_fontello_fonts_transient( true ) : ''; ?>

            <table class="form-table">
                <tbody>
                    <tr valign="top">
                        <th scope="row"><?php esc_html_e('Choose an Icon Font:', 'tsm_shop'); ?></th>
                        <td>
                            <div id="tsm-shop-icon-fonts-select-wrapper">
                                <select id="tsm-shop-icon-fonts-select" data-placeholder="Select an Icon" style="width: 314px">
                                    <option value=""></option>
<?php                               if ( $tsm_shop_fa_icons ) : ?>
                                        <optgroup label="<?php esc_html_e('Font Awesome Icons:', 'tsm_shop'); ?>" class="fa-optgroup" role="fa-optgroup">
<?php                                   foreach ( $tsm_shop_fa_icons as $fa_icon ) : ?>
                                            <option data-css-prefix="fa "><?php echo $fa_icon; ?></option>
<?php                                   endforeach; ?>
                                        </optgroup>
<?php                               endif; ?>
<?php                               if ( $tsm_shop_fontello_icons ) : ?>
                                        <optgroup label="<?php esc_html_e('Fontello Icons:', 'tsm_shop'); ?>" class="fontello-optgroup" role="fontello-optgroup">
<?php                                   foreach ( $tsm_shop_fontello_icons as $icon ) : ?>
                                            <option data-css-prefix="icon-"><?php echo $icon; ?></option>
<?php                                   endforeach; ?>
                                        </optgroup>
<?php                               endif; ?>
                                </select>
                            </div>
                            <div class="clear"></div>
<?php                       $num_tsm_shop_fa_icons = ( $tsm_shop_fa_icons == '' ) ? '0' : count( $tsm_shop_fa_icons );
                            $num_fontello_icons = ( $tsm_shop_fontello_icons == '' ) ? '0' : count( $tsm_shop_fontello_icons ); ?>
                            <span class="description" style="margin-top: 10px; display: inline-block;"><?php printf( __('Total Icons: %1$s  (Font Awesome) + %2$s  (Fontello)', 'tsm_shop'), 
                                    '<strong>' . $num_tsm_shop_fa_icons . '</strong>', 
                                    '<strong>' . $num_fontello_icons . '</strong>' ); ?></span>
                        </td>
                    </tr>
                </tbody>
            </table>
<?php   }
        echo tsm_shop_add_icon_select_option(); ?>

        <table class="form-table">
            <tbody>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Icon Font Color:', 'tsm_shop'); ?></th>
                    <td>
                        <div id="tsm-shop-icon-font-color-picker-wrapper">
                            <label>
                                <input type="checkbox" id="tsm-shop-icon-font-color-inherit" value="inherit" checked /> <?php esc_html_e('Inherit default color or:', 'tsm_shop'); ?> 
                            </label>
                            <div class="clear"></div>
                            <input type="text" value="#4C4C4C" id="tsm-shop-icon-font-color-picker-field" data-default-color="#4C4C4C" />
                        </div>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Icon Font Size:', 'tsm_shop'); ?></th>
                    <td>
                        <span id="tsm-shop-icon-font-size-wrapper"><span id="tsm-shop-icon-font-size">1</span> em</span> <span id="tsm-shop-icon-font-size-slider"></span><br />
                        <span class="description" style="margin-top: 6px; display: inline-block;"><?php esc_html_e('"1 em" is the default (inherit) text size, hence it will not be included in the code/shortcode.', 'tsm_shop'); ?></span>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Other Options:', 'tsm_shop'); ?></th>
                    <td>
                        <fieldset style="margin-top:5px;"><legend class="screen-reader-text"><span><?php esc_html_e("Animated Spin:", 'tsm_shop'); ?></span></legend>
                            <label>
                                <input type="checkbox" id="tsm-shop-fontello-icons-animate-spin" value="animate" />
                                <?php esc_html_e('Add animated spin', 'tsm_shop'); ?>
                            </label>
                        </fieldset>

                        <fieldset style="margin-top:5px;"><legend class="screen-reader-text"><span><?php esc_html_e("Wrap In Circle:", 'tsm_shop'); ?></span></legend>
                            <label>
                                <input type="checkbox" id="tsm-shop-fontello-icons-wrap-in-circle" value="animate" />
                                <?php esc_html_e('Wrap in a circle', 'tsm_shop'); ?>
                            </label>
                        </fieldset>
                    </td>
                </tr>
            </tbody>
        </table>

        <div id="tsm-shop-preview-icon-fonts-container">
            <div id="tsm-shop-close-review-button"><a id="tsm-shop-close-review-button-link" href="#"><div class="ud-if-close-icon"></div></a></div>
            <input type="button" id="preview-icon-font-btn" class="button-secondary preview-closed" value="<?php echo __('Show Preview', 'tsm_shop'); ?>" />
            <div class="clear"></div>
            <div id="tsm-shop-preview-icon-fonts-wrapper">
                <div id="tsm-shop-preview-icon-fonts-html-wrapper">
                    <div id="tsm-shop-preview-icon-font"></div>
                </div>
                <div class="clear"></div>
                <strong>Shortcode:</strong>
                <div id="tsm-shop-preview-icon-fonts-shortcode"></div>
                <div class="clear"></div>
                <strong>HTML:</strong>
                <div id="tsm-shop-preview-icon-fonts-html"></div>
            </div>
        </div>

        <table class="form-table">
            <tbody>
                <tr valign="top">
                    <td>
                        <fieldset style="margin-top:5px;"><legend class="screen-reader-text"><span><?php esc_html_e("HTML Version:", 'tsm_shop'); ?></span></legend>
                            <label>
                                <input type="checkbox" id="tsm-shop-fontello-icons-as-html" value="animate" />
                                <?php esc_html_e('Insert as HTML (shortcode version is used by default, see the preview above for details)', 'tsm_shop'); ?>
                            </label>
                        </fieldset>
                    </td>
                </tr>
            </tbody>
        </table>


        <p id="tsm-shop-icon-font-insert-button" class="submit">
            <input type="button" id="insert-icon-font-btn" class="button-primary" value="<?php echo __('Insert Icon', 'tsm_shop'); ?>" />
            <a id="cancel-icon-insertion" class="button-secondary" onclick="tb_remove();" title="<?php _e('Cancel', 'tsm_shop'); ?>"><?php _e('Cancel', 'tsm_shop'); ?></a>
        </p>


        <?php $tsm_shop_fontello_css_prefix_text = tsm_shop_fontello_css_prefix_text(); ?>
        
        <script type="text/javascript">
        // <![CDATA[
        jQuery(document).ready(function ($) {
            
            function addIcontoListItem(item) {
                var classPrefix = item.element;
                if (!item.id) return item.text; // optgroup
                return "<span class=\"icon-font-item\"><i class='" + $(classPrefix).data('css-prefix') + item.text + "'></i> " + item.text + '</span>';
            }
            $("#tsm-shop-icon-fonts-select").select2({
                theme: "classic",
                placeholder: "Choose an Icon Font",
                allowClear: true,
                templateResult: addIcontoListItem,
                templateSelection: addIcontoListItem,
                escapeMarkup: function(m) { return m; }
            })
            .on("change", function(e) {
                // update preview on font change if preview is opened of course
                if ( $('#preview-icon-font-btn').hasClass('preview-opened') ) {
                    displayIconPreviewContent();
                }
            }).on("select2-removed", function(e) {
                $('#tsm-shop-preview-icon-fonts-wrapper').delay(100).fadeOut(400, function(){
                        $('#preview-icon-font-btn').removeClass('preview-opened').addClass('preview-closed');
                 });
                 $('#tsm-shop-close-review-button').css("display", "none");
            });
            
            // deal with the color picker
            var myOptions = {
                // you can declare a default color here,
                // or in the data-default-color attribute on the input
                defaultColor: false,
                // a callback to fire whenever the color changes to a valid color
                change: function(event, ui){
                    // uncheck the "inherit default color" checkbox:
                    $('#tsm-shop-icon-font-color-inherit').prop('checked', false);
                    // update preview on color change if preview is opened of course
                    if ( $('#preview-icon-font-btn').hasClass('preview-opened') ) {
                        var selectedColor = ui.color.toString();
                        $('.wp-picker-input-wrap input#tsm-shop-icon-font-color-picker-field').val( selectedColor );
                        displayIconPreviewContent();
                    }
                },
                // a callback to fire when the input is emptied or an invalid color
                clear: function() {},
                // hide the color picker controls on load
                hide: true,
                // show a group of common colors beneath the square
                // or, supply an array of colors to customize further
                palettes: true
            };
            $('#tsm-shop-icon-font-color-picker-field').wpColorPicker( myOptions );


            // Preview section
            $('#preview-icon-font-btn').on( "click", function() {
                var thePreviewButton = $( this );
                var selectedIcon = $('#tsm-shop-icon-fonts-select').val();
                if ( ! selectedIcon ) { alert( "Please select an icon..." ); return false; }
                displayIconPreviewContent();
                $('#tsm-shop-preview-icon-fonts-wrapper').delay(100).fadeIn(400, function(){
                    thePreviewButton.removeClass('preview-closed').addClass('preview-opened');
                    $('#tsm-shop-close-review-button').css("display", "block");
                 });
            });

            // close the preview popup
            $('#tsm-shop-close-review-button a').on( "click", function() {
                $('#tsm-shop-preview-icon-fonts-wrapper').delay(100).fadeOut(400, function(){
                        $('#preview-icon-font-btn').removeClass('preview-opened').addClass('preview-closed');
                 });
                 $('#tsm-shop-close-review-button').css("display", "none");
            });
            // update on "inherit default color" checkbox
            $('#tsm-shop-icon-font-color-inherit').change(function() {
                if ( $('#preview-icon-font-btn').hasClass('preview-opened') ) {
                    displayIconPreviewContent();
                }
            });
            // update on animate-change-spin checkbox
            $('#tsm-shop-fontello-icons-animate-spin').change(function() {
                if ( $('#preview-icon-font-btn').hasClass('preview-opened') ) {
                    displayIconPreviewContent();
                }
            });
            // update on circle-wrap checkbox
            $('#tsm-shop-fontello-icons-wrap-in-circle').change(function() {
                if ( $('#preview-icon-font-btn').hasClass('preview-opened') ) {
                    displayIconPreviewContent();
                }
            });

            // Construct the final HTML or Shortcode of a selected icon font
            function getTheIconFontCode( htmlOrShortcode ) {
                var selectedIcon = $('#tsm-shop-icon-fonts-select').val();
                var selectedIsFontAwesome = $('#tsm-shop-icon-fonts-select :selected').closest('optgroup').hasClass('fa-optgroup');
                var classPrefix = ( selectedIcon.substring(0, 3) === 'fa-' ) ? 'fa ' : '<?php echo $tsm_shop_fontello_css_prefix_text; ?>';
                var iconColorInherit = ( $('#tsm-shop-icon-font-color-inherit').is(':checked') ) ? 'inherit' : '';
                var iconColor = ( iconColorInherit === '' ) ? $('.wp-picker-input-wrap input#tsm-shop-icon-font-color-picker-field').val() : '';
                var iconSize = $('#tsm-shop-icon-font-size').text();
                if ( $('#tsm-shop-fontello-icons-animate-spin').is(':checked') ) {
                    var iconAnimateSpin = ( selectedIsFontAwesome ) ? ' fa-spin' : ' animate-spin';
                } else {
                    var iconAnimateSpin = '';
                }
                var iconCircleWrap = ( $('#tsm-shop-fontello-icons-wrap-in-circle').is(':checked') ) ? ' circle-wrap' : '';

                if ( htmlOrShortcode === 'html' ) {
                    // when html version requested:
                    iconSize = ( iconSize !== '1' ) ?  'font-size:' + iconSize + 'em;' : '';
                    var iconColorForHTML = ( iconColor !== '' ) ?  'color:' + iconColor + ';' : '';
                    var inlineStyles = ( iconColorForHTML !== '' || iconSize !== '' ) ?  ' style="' + iconColorForHTML + iconSize + '"' : '';
                    return ' <i class="' + classPrefix + selectedIcon + iconAnimateSpin + iconCircleWrap + '"' + inlineStyles + '><!-- icon --></i> ';
                }
                // when shortcode version requested:
                iconSize = ( iconSize !== '1' ) ?  ' size="' + iconSize + 'em"' : '';
                iconColor = ( iconColor !== '' ) ?  ' color="' + iconColor + '"' : '';
                return '[tsm_shop_icon_font name="' + classPrefix + selectedIcon + iconAnimateSpin + iconCircleWrap + '"' + iconColor + iconSize + '] ';
            }
            // Display the preview content function
            function displayIconPreviewContent() {
                var htmlString = getTheIconFontCode( 'html' );
                var shortcodeString = getTheIconFontCode( 'shortcode' );
                $('#tsm-shop-preview-icon-font').html( htmlString );
                $('#tsm-shop-preview-icon-fonts-html').text( htmlString );
                $('#tsm-shop-preview-icon-fonts-shortcode').text( shortcodeString );
            }

            // Handle the Insert and Cancel buttons
            $('#insert-icon-font-btn').on( "click", function() {
                var selectedIcon = $('#tsm-shop-icon-fonts-select').val();
                if ( ! selectedIcon ) { alert( "Please select an icon..." ); return false; }

                if ( $('#tsm-shop-fontello-icons-as-html').is(':checked') ) {
                    window.send_to_editor( getTheIconFontCode( 'html' ) );
                    return false;
                }
                window.send_to_editor( getTheIconFontCode( 'shortcode' ) );
                return false;
            });


            // Slide bar for the fonts size option
            var tsmshopIconFontSize = $( "#tsm-shop-icon-font-size" );
            var tsmshopIconFontSizeSlider = $( "#tsm-shop-icon-font-size-slider" );
            tsmshopIconFontSizeSlider.slider({
                range: "max",
                min: 0.7,
                max: 10.00,
                step: 0.1,
                value: [ tsmshopIconFontSize.text() ],
                slide: function( event, ui ) {
                    tsmshopIconFontSize.text( ui.value );
                    // update preview on the following options change if preview is opened of course
                    if ( $('#preview-icon-font-btn').hasClass('preview-opened') ) {
                        displayIconPreviewContent();
                    }
                }
            });


        });
        // ]]>
        </script>

    </div>
<?php
}
add_action('admin_footer', 'tsm_shop_icon_fonts_popup_content');


function tsm_shop_icon_fonts_color_picker( ) {
    wp_enqueue_style( 'wp-color-picker' );
    wp_enqueue_script( 'wp-color-picker' );
    
    global $wp_scripts;
    wp_enqueue_script('jquery-ui-core');
    wp_enqueue_script('jquery-ui-slider');
    // get the jquery ui object
    $queryui = $wp_scripts->query('jquery-ui-core');
    // load the jquery ui theme
    $scheme = is_ssl() ? 'https://' : 'http://';
    $url = $scheme . "code.jquery.com/ui/".$queryui->ver."/themes/flick/jquery-ui.min.css";
    wp_enqueue_style('jquery-ui-smoothness', $url, false, null);
}
add_action( 'admin_enqueue_scripts', 'tsm_shop_icon_fonts_color_picker' );





