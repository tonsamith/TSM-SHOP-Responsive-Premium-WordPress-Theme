selectnav('main-top-menu', {
    activeclass: 'current-menu-item',
    label: '--- ' + tsm_shop_selectnav_vars.selectnav_menu_label + ' --- ',
    indent: '--'
});