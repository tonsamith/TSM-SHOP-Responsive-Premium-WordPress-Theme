<?php 

/**
 * List of TSM-SHOP action hook functions
 * 
 */
if ( !defined( 'ABSPATH' ) ) exit; // Exit if accessed directly




/**********************( <html> hooks )*********************/

/**
 * Fire the 'tsm_shop_html_before' action
 * Useful for <DOCTYPE>, etc.
 *
 * @uses do_action() Calls 'tsm_shop_html_before' hook.
 */
function tsm_shop_html_before() {
    do_action('tsm_shop_html_before');
}



/**********************( <head> hooks )*********************/

/**
 * Fire the 'tsm_shop_head_top' action
 *
 * @uses do_action() Calls 'tsm_shop_head_top' hook.
 */
function tsm_shop_head_top() {
    do_action('tsm_shop_head_top');
}

/**
 * Fire the 'tsm_shop_head_bottom' action
 *
 * @uses do_action() Calls 'tsm_shop_head_bottom' hook.
 */
function tsm_shop_head_bottom() {
    do_action('tsm_shop_head_bottom');
}



/**********************( <body> hooks )*********************/

/**
 * Fire the 'tsm_shop_inside_body_tag' action
 *
 * @uses do_action() Calls 'tsm_shop_inside_body_tag' hook.
 */
function tsm_shop_inside_body_tag() {
    do_action('tsm_shop_inside_body_tag');
}

/**
 * Fire the 'tsm_shop_body_top' action
 *
 * @uses do_action() Calls 'tsm_shop_body_top' hook.
 */
function tsm_shop_body_top() {
    do_action('tsm_shop_body_top');
}

/**
 * Fire the 'tsm_shop_body_bottom' action
 *
 * @uses do_action() Calls 'tsm_shop_body_bottom' hook.
 */
function tsm_shop_body_bottom() {
    do_action('tsm_shop_body_bottom');
}

 

/**********************( <top-wrapper> hooks )*********************/

/**
 * Fire the 'tsm_shop_top_wrapper_before' action
 *
 * @uses do_action() Calls 'tsm_shop_top_wrapper_before' hook.
 */
function tsm_shop_top_wrapper_before() {
    do_action('tsm_shop_top_wrapper_before');
}

/**
 * Fire the 'tsm_shop_top_wrapper_after' action.
 * Passes as an argument (boolean) whether the current page is front page or not
 * 
 * @param bool $is_front_page Based on call to is_front_page() core WordPress function
 * @uses do_action() Calls 'tsm_shop_top_wrapper_after' hook.
 */
function tsm_shop_top_wrapper_after( $is_front_page ) {
    do_action('tsm_shop_top_wrapper_after', $is_front_page);
}

/**
 * Fire the 'tsm_shop_top_wrapper_top' action
 *
 * @uses do_action() Calls 'tsm_shop_top_wrapper_top' hook.
 */
function tsm_shop_top_wrapper_top() {
    do_action('tsm_shop_top_wrapper_top');
}

/**
 * Fire the 'tsm_shop_top_wrapper_bottom' action
 * Passes as an argument (boolean) whether the current page is front page or not
 *
 * @param bool $is_front_page Based on call to is_front_page() core WordPress function
 * @uses do_action() Calls 'tsm_shop_top_wrapper_bottom' hook.
 */
function tsm_shop_top_wrapper_bottom( $is_front_page ) {
    do_action('tsm_shop_top_wrapper_bottom', $is_front_page);
}
 


/**********************( <top-elements> hooks )*********************/

/**
 * Fire the 'tsm_shop_top_elements_inside' action
 * Passes as an argument (boolean) whether the current page is front page or not
 *
 * @param bool $is_front_page Based on call to is_front_page() core WordPress function
 * @uses do_action() Calls 'tsm_shop_top_elements_inside' hook.
 */
function tsm_shop_top_elements_inside( $is_front_page ) {
    do_action('tsm_shop_top_elements_inside', $is_front_page);
}

  

/**********************( front page slider hooks )*********************/

/**
 * Fire the 'tsm_shop_front_page_slider_before' action
 *
 * @uses do_action() Calls 'tsm_shop_front_page_slider_before' hook.
 */
function tsm_shop_front_page_slider_before() {
    do_action('tsm_shop_front_page_slider_before');
}

/**
 * Fire the 'tsm_shop_front_page_slider_after' action
 *
 * @uses do_action() Calls 'tsm_shop_front_page_slider_after' hook.
 */
function tsm_shop_front_page_slider_after() {
    do_action('tsm_shop_front_page_slider_after');
}
 
 
 
/**********************( <home-page-content> and <page-content> hooks )*********************/

/**
 * Fire the 'tsm_shop_home_page_content_before' action
 *
 * @uses do_action() Calls 'tsm_shop_home_page_content_before' hook.
 */
function tsm_shop_home_page_content_before() {
    do_action('tsm_shop_home_page_content_before');
}

/**
 * Fire the 'tsm_shop_page_content_before' action.
 * 
 * @uses do_action() Calls 'tsm_shop_page_content_before' hook.
 */
function tsm_shop_page_content_before() {
    do_action('tsm_shop_page_content_before');
}

/**
 * Fire the 'tsm_shop_page_content_after' action.
 * 
 * @uses do_action() Calls 'tsm_shop_page_content_after' hook.
 */
function tsm_shop_page_content_after() {
    do_action('tsm_shop_page_content_after');
}

/**
 * Fire the 'tsm_shop_home_page_content_top' action
 *
 * @uses do_action() Calls 'tsm_shop_home_page_content_top' hook.
 */
function tsm_shop_home_page_content_top() {
    do_action('tsm_shop_home_page_content_top');
}

/**
 * Fire the 'tsm_shop_page_content_top' action
 *
 * @uses do_action() Calls 'tsm_shop_page_content_top' hook.
 */
function tsm_shop_page_content_top() {
    do_action('tsm_shop_page_content_top');
}

/**
 * Fire the 'tsm_shop_page_content_bottom' action
 *
 * @uses do_action() Calls 'tsm_shop_page_content_bottom' hook.
 */
function tsm_shop_page_content_bottom() {
    do_action('tsm_shop_page_content_bottom');
}

 
 
/**********************( <page-title> hooks )*********************/

/**
 * Fire the 'tsm_shop_page_title_before' action
 *
 * @uses do_action() Calls 'tsm_shop_page_title_before' hook.
 */
function tsm_shop_page_title_before() {
    do_action('tsm_shop_page_title_before');
}

/**
 * Fire the 'tsm_shop_page_title_after' action.
 * 
 * @uses do_action() Calls 'tsm_shop_page_title_after' hook.
 */
function tsm_shop_page_title_after() {
    do_action('tsm_shop_page_title_after');
}

/**
 * Fire the 'tsm_shop_page_title_top' action
 *
 * @uses do_action() Calls 'tsm_shop_page_title_top' hook.
 */
function tsm_shop_page_title_top() {
    do_action('tsm_shop_page_title_top');
}

/**
 * Fire the 'tsm_shop_page_title_bottom' action.
 * 
 * @uses do_action() Calls 'tsm_shop_page_title_bottom' hook.
 */
function tsm_shop_page_title_bottom() {
    do_action('tsm_shop_page_title_bottom');
}
 
 
/**********************( <main-content> hook )*********************/

/**
 * Fire the 'tsm_shop_main_content_top' action
 * Passes as an argument (boolean) whether the current page is front page or not
 * 
 * @param bool $is_front_page Based on call to is_front_page() core WordPress function
 * @uses do_action() Calls 'tsm_shop_main_content_top' hook.
 */
function tsm_shop_main_content_top( $is_front_page ) {
    do_action('tsm_shop_main_content_top', $is_front_page);
}

/**
 * Fire the 'tsm_shop_main_content_bottom' action.
 * 
 * @uses do_action() Calls 'tsm_shop_main_content_bottom' hook.
 */
function tsm_shop_main_content_bottom() {
    do_action('tsm_shop_main_content_bottom');
}


/**********************( <entry> hooks )*********************/

/**
 * Fire the 'tsm_shop_entry_before' action
 *
 * @uses do_action() Calls 'tsm_shop_entry_before' hook.
 */
function tsm_shop_entry_before() {
    do_action('tsm_shop_entry_before');
}

/**
 * Fire the 'tsm_shop_entry_after' action.
 * 
 * @uses do_action() Calls 'tsm_shop_entry_after' hook.
 */
function tsm_shop_entry_after() {
    do_action('tsm_shop_entry_after');
}

/**
 * Fire the 'tsm_shop_entry_top' action
 *
 * @uses do_action() Calls 'tsm_shop_entry_top' hook.
 */
function tsm_shop_entry_top() {
    do_action('tsm_shop_entry_top');
}

/**
 * Fire the 'tsm_shop_entry_bottom' action.
 * 
 * @uses do_action() Calls 'tsm_shop_entry_bottom' hook.
 */
function tsm_shop_entry_bottom() {
    do_action('tsm_shop_entry_bottom');
}


/**********************( blog posts <entry> hooks )*********************/

/**
 * Fire the 'tsm_shop_blog_entry_before' action
 *
 * @uses do_action() Calls 'tsm_shop_blog_entry_before' hook.
 */
function tsm_shop_blog_entry_before() {
    do_action('tsm_shop_blog_entry_before');
}

/**
 * Fire the 'tsm_shop_blog_entry_after' action.
 * 
 * @uses do_action() Calls 'tsm_shop_blog_entry_after' hook.
 */
function tsm_shop_blog_entry_after() {
    do_action('tsm_shop_blog_entry_after');
}

/**
 * Fire the 'tsm_shop_blog_entry_top' action
 *
 * @uses do_action() Calls 'tsm_shop_blog_entry_top' hook.
 */
function tsm_shop_blog_entry_top() {
    do_action('tsm_shop_blog_entry_top');
}

/**
 * Fire the 'tsm_shop_blog_entry_bottom' action.
 * 
 * @uses do_action() Calls 'tsm_shop_blog_entry_bottom' hook.
 */
function tsm_shop_blog_entry_bottom() {
    do_action('tsm_shop_blog_entry_bottom');
}

/**
 * Fire the 'tsm_shop_blog_post_content_before' action.
 * 
 * @uses do_action() Calls 'tsm_shop_blog_post_content_before' hook.
 */
function tsm_shop_blog_post_content_before() {
    do_action('tsm_shop_blog_post_content_before');
}

/**
 * Fire the 'tsm_shop_single_post_entry_before' action
 *
 * @uses do_action() Calls 'tsm_shop_single_post_entry_before' hook.
 */
function tsm_shop_single_post_entry_before() {
    do_action('tsm_shop_single_post_entry_before');
}

/**
 * Fire the 'tsm_shop_single_post_entry_after' action.
 * 
 * @uses do_action() Calls 'tsm_shop_single_post_entry_after' hook.
 */
function tsm_shop_single_post_entry_after() {
    do_action('tsm_shop_single_post_entry_after');
}

/**
 * Fire the 'tsm_shop_single_post_entry_top' action
 *
 * @uses do_action() Calls 'tsm_shop_single_post_entry_top' hook.
 */
function tsm_shop_single_post_entry_top() {
    do_action('tsm_shop_single_post_entry_top');
}

/**
 * Fire the 'tsm_shop_single_post_entry_bottom' action.
 * 
 * @uses do_action() Calls 'tsm_shop_single_post_entry_bottom' hook.
 */
function tsm_shop_single_post_entry_bottom() {
    do_action('tsm_shop_single_post_entry_bottom');
}


/**********************( blog posts <post-top> hooks )*********************/

/**
 * Fire the 'tsm_shop_blog_post_top_area_inside' action
 *
 * @uses do_action() Calls 'tsm_shop_blog_post_top_area_inside' hook.
 */
function tsm_shop_blog_post_top_area_inside() {
    do_action('tsm_shop_blog_post_top_area_inside');
}




/**********************( portfolio <entry> hooks )*********************/

/**
 * Fire the 'tsm_shop_single_portfolio_entry_before' action
 *
 * @uses do_action() Calls 'tsm_shop_single_portfolio_entry_before' hook.
 */
function tsm_shop_single_portfolio_entry_before() {
    do_action('tsm_shop_single_portfolio_entry_before');
}

/**
 * Fire the 'tsm_shop_single_portfolio_entry_after' action.
 * 
 * @uses do_action() Calls 'tsm_shop_single_portfolio_entry_after' hook.
 */
function tsm_shop_single_portfolio_entry_after() {
    do_action('tsm_shop_single_portfolio_entry_after');
}

/**
 * Fire the 'tsm_shop_single_portfolio_entry_top' action
 *
 * @uses do_action() Calls 'tsm_shop_single_portfolio_entry_top' hook.
 */
function tsm_shop_single_portfolio_entry_top() {
    do_action('tsm_shop_single_portfolio_entry_top');
}

/**
 * Fire the 'tsm_shop_single_portfolio_entry_bottom' action.
 * 
 * @uses do_action() Calls 'tsm_shop_single_portfolio_entry_bottom' hook.
 */
function tsm_shop_single_portfolio_entry_bottom() {
    do_action('tsm_shop_single_portfolio_entry_bottom');
}


/**********************( <bottom> hooks )*********************/

/**
 * Fire the 'tsm_shop_bottom_section_top' action
 *
 * @uses do_action() Calls 'tsm_shop_bottom_section_top' hook.
 */
function tsm_shop_bottom_section_top() {
    do_action('tsm_shop_bottom_section_top');
}

/**
 * Fire the 'tsm_shop_bottom_section_bottom' action.
 * 
 * @uses do_action() Calls 'tsm_shop_bottom_section_bottom' hook.
 */
function tsm_shop_bottom_section_bottom() {
    do_action('tsm_shop_bottom_section_bottom');
}




/**********************( <footer> hooks )*********************/

/**
 * Fire the 'tsm_shop_footer_before' action
 *
 * @uses do_action() Calls 'tsm_shop_footer_before' hook.
 */
function tsm_shop_footer_before() {
    do_action('tsm_shop_footer_before');
}

/**
 * Fire the 'tsm_shop_footer_after' action.
 * 
 * @uses do_action() Calls 'tsm_shop_footer_after' hook.
 */
function tsm_shop_footer_after() {
    do_action('tsm_shop_footer_after');
}

/**
 * Fire the 'tsm_shop_footer_inside' action
 *
 * @uses do_action() Calls 'tsm_shop_footer_inside' hook.
 */
function tsm_shop_footer_inside() {
    do_action('tsm_shop_footer_inside');
}




/**********************( <sidebar> hooks )*********************/

/**
 * Fire the 'tsm_shop_sidebar_top' action
 *
 * @uses do_action() Calls 'tsm_shop_sidebar_top' hook.
 */
function tsm_shop_sidebar_top() {
    do_action('tsm_shop_sidebar_top');
}

/**
 * Fire the 'tsm_shop_sidebar_bottom' action.
 * 
 * @uses do_action() Calls 'tsm_shop_sidebar_bottom' hook.
 */
function tsm_shop_sidebar_bottom() {
    do_action('tsm_shop_sidebar_bottom');
}








