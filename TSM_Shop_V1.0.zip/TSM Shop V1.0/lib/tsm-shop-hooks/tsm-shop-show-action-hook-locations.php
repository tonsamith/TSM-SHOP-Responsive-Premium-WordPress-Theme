<?php 

/* 
 * The below code deals with the display of the action hooks in the front end has the user enabled that option.
 * Enabling the "Show Action Hook Locations" from "Advaned Options" will allow you to see in the front end the exact locations of the U-Design action hooks located within the "body" tags.
 * 
 */
if ( !defined( 'ABSPATH' ) ) exit; // Exit if accessed directly



function tsm_shop_body_top_function() {
   echo '<div class="--> action-hook-ref tsm_shop_body_top"><span>tsm_shop_body_top</span></div>';
}
add_action('tsm_shop_body_top', 'tsm_shop_body_top_function', 10);

function tsm_shop_body_bottom_function() {
   echo '<div class="--> action-hook-ref tsm_shop_body_bottom"><span>tsm_shop_body_bottom</span></div>';
}
add_action('tsm_shop_body_bottom', 'tsm_shop_body_bottom_function', 10);

function tsm_shop_top_wrapper_before_function() {
   echo '<div class="--> action-hook-ref tsm_shop_top_wrapper_before"><span>tsm_shop_top_wrapper_before</span></div>';
}
add_action('tsm_shop_top_wrapper_before', 'tsm_shop_top_wrapper_before_function', 10);

function tsm_shop_top_wrapper_after_function( $is_front_page ) {
   echo '<div class="--> action-hook-ref tsm_shop_top_wrapper_after"><span>tsm_shop_top_wrapper_after <em>&nbsp;( $is_front_page boolean parameter passed )</em></span></div>';
}
add_action('tsm_shop_top_wrapper_after', 'tsm_shop_top_wrapper_after_function', 10);

function tsm_shop_top_wrapper_top_function() {
   echo '<div class="--> action-hook-ref tsm_shop_top_wrapper_top"><span>tsm_shop_top_wrapper_top</span></div>';
}
add_action('tsm_shop_top_wrapper_top', 'tsm_shop_top_wrapper_top_function', 10);

function tsm_shop_top_wrapper_bottom_function( $is_front_page ) {
   echo '<div class="--> action-hook-ref tsm_shop_top_wrapper_bottom"><span>tsm_shop_top_wrapper_bottom <em>&nbsp;( $is_front_page boolean parameter passed )</em></span></div>';
}
add_action('tsm_shop_top_wrapper_bottom', 'tsm_shop_top_wrapper_bottom_function', 10);

function tsm_shop_top_elements_inside_function( $is_front_page ) {
   echo '<div class="--> action-hook-ref tsm_shop_top_elements_inside"><span>tsm_shop_top_elements_inside <em>&nbsp;( $is_front_page boolean parameter passed )</em></span></div>';
}
add_action('tsm_shop_top_elements_inside', 'tsm_shop_top_elements_inside_function', 10);

function tsm_shop_front_page_slider_before_function() {
   echo '<div class="--> action-hook-ref tsm_shop_front_page_slider_before"><span>tsm_shop_front_page_slider_before</span></div>';
}
add_action('tsm_shop_front_page_slider_before', 'tsm_shop_front_page_slider_before_function', 10);

function tsm_shop_front_page_slider_after_function() {
   echo '<div class="--> action-hook-ref tsm_shop_front_page_slider_after"><span>tsm_shop_front_page_slider_after</span></div>';
}
add_action('tsm_shop_front_page_slider_after', 'tsm_shop_front_page_slider_after_function', 10);

function tsm_shop_home_page_content_before_function() {
   echo '<div class="--> action-hook-ref tsm_shop_home_page_content_before"><span>tsm_shop_home_page_content_before</span></div>';
}
add_action('tsm_shop_home_page_content_before', 'tsm_shop_home_page_content_before_function', 10);

function tsm_shop_page_content_before_function() {
   echo '<div class="--> action-hook-ref tsm_shop_page_content_before"><span>tsm_shop_page_content_before</span></div>';
}
add_action('tsm_shop_page_content_before', 'tsm_shop_page_content_before_function', 10);

function tsm_shop_page_content_after_function() {
   echo '<div class="--> action-hook-ref tsm_shop_page_content_after"><span>tsm_shop_page_content_after</span></div>';
}
add_action('tsm_shop_page_content_after', 'tsm_shop_page_content_after_function', 10);

function tsm_shop_home_page_content_top_function() {
   echo '<div class="--> action-hook-ref tsm_shop_home_page_content_top"><span>tsm_shop_home_page_content_top</span></div>';
}
add_action('tsm_shop_home_page_content_top', 'tsm_shop_home_page_content_top_function', 10);

function tsm_shop_page_content_top_function() {
   echo '<div class="--> action-hook-ref tsm_shop_page_content_top"><span>tsm_shop_page_content_top</span></div>';
}
add_action('tsm_shop_page_content_top', 'tsm_shop_page_content_top_function', 10);

function tsm_shop_page_content_bottom_function() {
   echo '<div class="--> action-hook-ref tsm_shop_page_content_bottom"><span>tsm_shop_page_content_bottom</span></div>';
}
add_action('tsm_shop_page_content_bottom', 'tsm_shop_page_content_bottom_function', 10);

function tsm_shop_page_title_before_function() {
   echo '<div class="--> action-hook-ref tsm_shop_page_title_before"><span>tsm_shop_page_title_before</span></div>';
}
add_action('tsm_shop_page_title_before', 'tsm_shop_page_title_before_function', 10);

function tsm_shop_page_title_after_function() {
   echo '<div class="--> action-hook-ref tsm_shop_page_title_after"><span>tsm_shop_page_title_after</span></div>';
}
add_action('tsm_shop_page_title_after', 'tsm_shop_page_title_after_function', 10);

function tsm_shop_page_title_top_function() {
   echo '<div class="--> action-hook-ref tsm_shop_page_title_top"><span>tsm_shop_page_title_top</span></div>';
}
add_action('tsm_shop_page_title_top', 'tsm_shop_page_title_top_function', 10);

function tsm_shop_page_title_bottom_function() {
   echo '<div class="--> action-hook-ref tsm_shop_page_title_bottom"><span>tsm_shop_page_title_bottom</span></div>';
}
add_action('tsm_shop_page_title_bottom', 'tsm_shop_page_title_bottom_function', 10);

function tsm_shop_main_content_top_function( $is_front_page ) {
   echo '<div class="--> action-hook-ref tsm_shop_main_content_top"><span>tsm_shop_main_content_top <em>&nbsp;( $is_front_page boolean  parameter passed )</em></span></div>';
}
add_action('tsm_shop_main_content_top', 'tsm_shop_main_content_top_function', 10);

function tsm_shop_main_content_bottom_function() {
   echo '<div class="--> action-hook-ref tsm_shop_main_content_bottom"><span>tsm_shop_main_content_bottom</span></div>';
}
add_action('tsm_shop_main_content_bottom', 'tsm_shop_main_content_bottom_function', 10);

function tsm_shop_entry_before_function() {
   echo '<div class="--> action-hook-ref tsm_shop_entry_before"><span>tsm_shop_entry_before</span></div>';
}
add_action('tsm_shop_entry_before', 'tsm_shop_entry_before_function', 10);

function tsm_shop_entry_after_function() {
   echo '<div class="--> action-hook-ref tsm_shop_entry_after"><span>tsm_shop_entry_after</span></div>';
}
add_action('tsm_shop_entry_after', 'tsm_shop_entry_after_function', 10);

function tsm_shop_entry_top_function() {
   echo '<div class="--> action-hook-ref tsm_shop_entry_top"><span>tsm_shop_entry_top</span></div>';
}
add_action('tsm_shop_entry_top', 'tsm_shop_entry_top_function', 10);

function tsm_shop_entry_bottom_function() {
   echo '<div class="--> action-hook-ref tsm_shop_entry_bottom"><span>tsm_shop_entry_bottom</span></div>';
}
add_action('tsm_shop_entry_bottom', 'tsm_shop_entry_bottom_function', 10);

function tsm_shop_blog_entry_before_function() {
   echo '<div class="--> action-hook-ref tsm_shop_blog_entry_before"><span>tsm_shop_blog_entry_before</span></div>';
}
add_action('tsm_shop_blog_entry_before', 'tsm_shop_blog_entry_before_function', 10);

function tsm_shop_blog_entry_after_function() {
   echo '<div class="--> action-hook-ref tsm_shop_blog_entry_after"><span>tsm_shop_blog_entry_after</span></div>';
}
add_action('tsm_shop_blog_entry_after', 'tsm_shop_blog_entry_after_function', 10);

function tsm_shop_blog_entry_top_function() {
   echo '<div class="--> action-hook-ref tsm_shop_blog_entry_top"><span>tsm_shop_blog_entry_top</span></div>';
}
add_action('tsm_shop_blog_entry_top', 'tsm_shop_blog_entry_top_function', 10);

function tsm_shop_blog_entry_bottom_function() {
   echo '<div class="--> action-hook-ref tsm_shop_blog_entry_bottom"><span>tsm_shop_blog_entry_bottom</span></div>';
}
add_action('tsm_shop_blog_entry_bottom', 'tsm_shop_blog_entry_bottom_function', 10);

function tsm_shop_blog_post_content_before_function() {
   echo '<div class="--> action-hook-ref tsm_shop_blog_post_content_before"><span>tsm_shop_blog_post_content_before</span></div>';
}
add_action('tsm_shop_blog_post_content_before', 'tsm_shop_blog_post_content_before_function', 10);

function tsm_shop_single_post_entry_before_function() {
   echo '<div class="--> action-hook-ref tsm_shop_single_post_entry_before"><span>tsm_shop_single_post_entry_before</span></div>';
}
add_action('tsm_shop_single_post_entry_before', 'tsm_shop_single_post_entry_before_function', 10);

function tsm_shop_single_post_entry_after_function() {
   echo '<div class="--> action-hook-ref tsm_shop_single_post_entry_after"><span>tsm_shop_single_post_entry_after</span></div>';
}
add_action('tsm_shop_single_post_entry_after', 'tsm_shop_single_post_entry_after_function', 10);

function tsm_shop_single_post_entry_top_function() {
   echo '<div class="--> action-hook-ref tsm_shop_single_post_entry_top"><span>tsm_shop_single_post_entry_top</span></div>';
}
add_action('tsm_shop_single_post_entry_top', 'tsm_shop_single_post_entry_top_function', 10);

function tsm_shop_single_post_entry_bottom_function() {
   echo '<div class="--> action-hook-ref tsm_shop_single_post_entry_bottom"><span>tsm_shop_single_post_entry_bottom</span></div>';
}
add_action('tsm_shop_single_post_entry_bottom', 'tsm_shop_single_post_entry_bottom_function', 10);

function tsm_shop_blog_post_top_area_inside_function() {
   echo '<div class="--> action-hook-ref tsm_shop_blog_post_top_area_inside"><span>tsm_shop_blog_post_top_area_inside</span></div>';
}
add_action('tsm_shop_blog_post_top_area_inside', 'tsm_shop_blog_post_top_area_inside_function', 10);

function tsm_shop_single_portfolio_entry_before_function() {
   echo '<div class="--> action-hook-ref tsm_shop_single_portfolio_entry_before"><span>tsm_shop_single_portfolio_entry_before</span></div>';
}
add_action('tsm_shop_single_portfolio_entry_before', 'tsm_shop_single_portfolio_entry_before_function', 10);

function tsm_shop_single_portfolio_entry_after_function() {
   echo '<div class="--> action-hook-ref tsm_shop_single_portfolio_entry_after"><span>tsm_shop_single_portfolio_entry_after</span></div>';
}
add_action('tsm_shop_single_portfolio_entry_after', 'tsm_shop_single_portfolio_entry_after_function', 10);

function tsm_shop_single_portfolio_entry_top_function() {
   echo '<div class="--> action-hook-ref tsm_shop_single_portfolio_entry_top"><span>tsm_shop_single_portfolio_entry_top</span></div>';
}
add_action('tsm_shop_single_portfolio_entry_top', 'tsm_shop_single_portfolio_entry_top_function', 10);

function tsm_shop_single_portfolio_entry_bottom_function() {
   echo '<div class="--> action-hook-ref tsm_shop_single_portfolio_entry_bottom"><span>tsm_shop_single_portfolio_entry_bottom</span></div>';
}
add_action('tsm_shop_single_portfolio_entry_bottom', 'tsm_shop_single_portfolio_entry_bottom_function', 10);

function tsm_shop_bottom_section_top_function() {
   echo '<div class="--> action-hook-ref tsm_shop_bottom_section_top"><span>tsm_shop_bottom_section_top</span></div>';
}
add_action('tsm_shop_bottom_section_top', 'tsm_shop_bottom_section_top_function', 10);

function tsm_shop_bottom_section_bottom_function() {
   echo '<div class="--> action-hook-ref tsm_shop_bottom_section_bottom"><span>tsm_shop_bottom_section_bottom</span></div>';
}
add_action('tsm_shop_bottom_section_bottom', 'tsm_shop_bottom_section_bottom_function', 10);

function tsm_shop_footer_before_function() {
   echo '<div class="--> action-hook-ref tsm_shop_footer_before"><span>tsm_shop_footer_before</span></div>';
}
add_action('tsm_shop_footer_before', 'tsm_shop_footer_before_function', 10);

function tsm_shop_footer_after_function() {
   echo '<div class="--> action-hook-ref tsm_shop_footer_after"><span>tsm_shop_footer_after</span></div>';
}
add_action('tsm_shop_footer_after', 'tsm_shop_footer_after_function', 10);

function tsm_shop_footer_inside_function() {
   echo '<div class="--> action-hook-ref tsm_shop_footer_inside"><span>tsm_shop_footer_inside</span></div>';
}
add_action('tsm_shop_footer_inside', 'tsm_shop_footer_inside_function', 10);

function tsm_shop_sidebar_top_function() {
   echo '<div class="--> action-hook-ref tsm_shop_sidebar_top"><span>tsm_shop_sidebar_top</span></div>';
}
add_action('tsm_shop_sidebar_top', 'tsm_shop_sidebar_top_function', 10);

function tsm_shop_sidebar_bottom_function() {
   echo '<div class="--> action-hook-ref tsm_shop_sidebar_bottom"><span>tsm_shop_sidebar_bottom</span></div>';
}
add_action('tsm_shop_sidebar_bottom', 'tsm_shop_sidebar_bottom_function', 10);



