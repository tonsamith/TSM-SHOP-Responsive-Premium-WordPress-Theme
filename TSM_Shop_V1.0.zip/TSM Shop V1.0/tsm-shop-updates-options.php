<?php 
if ( !defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/*
	TSM-SHOP: Updates Options Page
        

        Contents:
	
		1. Default options
		2. Options menu
		3. Options page
		4. Register settings
		5. Section callbacks
		6. Settings callbacks
		7. Validate settings
                8. Miscellaneous functions

*/

global $tsm_shop_theme_update_options;
$tsm_shop_theme_update_options  = get_option('tsm_shop_theme_update_options');


// 1. Default options

function tsm_shop_theme_update_default_options() {
	$options = array(
                'input_theme_forest_username' => '',
                'input_theme_forest_api_key' => '',
	);
	return $options;
}


// 2. Options menu
function tsm_shop_updates_options_menu() {
	global $submenu;
	$tsm_shop_updates_admin_page =  add_submenu_page('tsm_shop_options_page', __( 'Theme Update', 'tsm_shop' ), __( 'Theme Update', 'tsm_shop' ), who_can_edit_tsm_shop_theme_options(), 'tsm_shop_updates_options_page', 'updates_options_page_callback');
        // Load the required styles and scripts conditionally to this page only
        add_action('load-'.$tsm_shop_updates_admin_page, 'load_tsm_shop_updates_page_scripts');
}
add_action('admin_menu', 'tsm_shop_updates_options_menu');

function load_tsm_shop_updates_page_scripts () {
    // Enque styles
    wp_enqueue_style('tsm-shop-udpates', get_template_directory_uri().'/scripts/admin/tsm-shop-updates-page-styles.css', false, '1.0', 'screen');
}

        
// 3. Options page
function updates_options_page_callback() {
        
        global $tsm_shop_theme_update_options; ?>
   
	<div class="wrap">
            <h1><?php _e('TSM-SHOP Theme Update Options', 'tsm_shop'); ?></h1>
            <?php  //settings_errors('tsm_shop_theme_update_options'); ?>

            
<?php       // do error checking and display notices 
            $user_name = $tsm_shop_theme_update_options['input_theme_forest_username'];
            $api_key =  $tsm_shop_theme_update_options['input_theme_forest_api_key'];

            if ( ! class_exists("Envato_Protected_API" )) {
                require_once( trailingslashit( get_template_directory() ) . "lib/updates/class-envato-api.php" );
            }
            $envato_protected_api = new Envato_Protected_API( $user_name, $api_key );
            $envato_protected_api->wp_list_themes( false ); // $allow_cache = false

            /* display API errors */
            $errors = $envato_protected_api->api_errors();
            if ( $errors ) {
                foreach ($errors as $k => $v) {
                    if ($k !== 'http_code' && ( $user_name || $api_key )) {
                        echo '<div class="error"><p>' . $v . '</p></div>';
                    }
                }
            }

            /* Display update messages */
            if ( empty( $errors ) ) {
                if ( isset($_GET['settings-updated']) || isset($_GET['updated']) ) {
                    echo '<div id="message" class="updated fade"><p><strong>'.esc_html__('Settings saved.', 'tsm_shop').'</strong></p></div>';
                }
            }
?>
            
            <form  id="tsm_shop_icon_fonts_submit_form" method="post" action="options.php">
                <h3 class="tsm-shop-updater-page-headers"><span class="dashicons dashicons-update"></span> <?php esc_html_e('UPDATE WITH WORDPRESS UPDATES', 'tsm_shop'); ?></h3>
                <?php settings_fields('tsm_shop_theme_update_options'); ?>
                <?php do_settings_sections('tsm_shop_theme_update_options'); ?>

                <div class="theme-update-submit-options-wrapper">

                    <div class="theme-update-submit">
                        <input type="submit" name="theme-update-submit" id="theme-update-submit" class="button button-primary tsm-shop-left-submit-btn" value="<?php esc_attr_e('Save Changes', 'tsm_shop') ?>"  />
                    </div>

                </div>
            </form>
            <div class="clear"></div>
            <div style="margin:20px 0 40px;">
                <?php printf( esc_html__('When a theme update is made available you will be notified and can update under the %s page.', 'tsm_shop'), 
                    '<a title="'.esc_html__('Go to the Updates page', 'tsm_shop').'" href="update-core.php">'.esc_html__('Dashboard &rarr; Updates', 'tsm_shop').'</a>' );
                ?>
                <span class="description"><?php esc_html_e('Please note: If you have successfully registered the above Username and API Key and no updates are showing up under the "Dashboard &rarr; Updates" page, wait a few minutes and refresh the page. It is because the API connection may be cached in the database.', 'tsm_shop' ); ?></span>
            </div>
            
<?php       tsm_shop_alternative_update_methods_info(); ?>
            
            
	</div>
        
<?php 

}



// 4. Register settings

// tab 'theme_update'
function tsm_shop_theme_update_register_settings() {
	
	if ( false == get_option('tsm_shop_theme_update_options') ) {	
		add_option( 'tsm_shop_theme_update_options', tsm_shop_theme_update_default_options() );
	}
	register_setting('tsm_shop_theme_update_options', 'tsm_shop_theme_update_options', 'tsm_shop_updates_validate_options');
	add_settings_section('field_tsm_shop_theme_update', __( 'ThemeForest Account Information', 'tsm_shop' ), 'field_tsm_shop_theme_update_callback', 'tsm_shop_theme_update_options');
	
	add_settings_field('input_theme_forest_username', __( 'ThemeForest Username:', 'tsm_shop' ), 'input_theme_forest_username_callback', 'tsm_shop_theme_update_options', 'field_tsm_shop_theme_update');
	add_settings_field('input_theme_forest_api_key', __( 'Secret ThemeForest API Key:', 'tsm_shop' ), 'input_theme_forest_api_key_callback', 'tsm_shop_theme_update_options', 'field_tsm_shop_theme_update');
        
}
add_action('admin_init', 'tsm_shop_theme_update_register_settings');


// 5. Section callbacks

// tab 'theme_update'
function field_tsm_shop_theme_update_callback() {
	echo '<p>';
        printf( esc_html__('In order to be able to update the theme you need to provide your ThemeForest Username and API Key for the account that you purchased the theme from. You can obtain an API key by visiting the %s (make sure that you are signed in) then clicking the "My Settings" tab. At the bottom of the page you will find your account\'s API key and a button to regenerate a new one if needed.', 'tsm_shop'), 
                '<a title="'.esc_html__('Go to http://themeforest.net/', 'tsm_shop').'" href="http://themeforest.net/" target="_blank">ThemeForest.net</a>' );
	echo '</p>';
}



// 6. Settings callbacks

// tab 'theme_update'
function input_theme_forest_username_callback() {
	$options = get_option('tsm_shop_theme_update_options'); ?>
        
        <input type="text" name="tsm_shop_theme_update_options[input_theme_forest_username]" id="input_theme_forest_username" value="<?php echo esc_attr($options['input_theme_forest_username']); ?>" size="32" />
        
        <?php 
}
function input_theme_forest_api_key_callback() {
	$options = get_option('tsm_shop_theme_update_options'); ?>
        
        <input type="password" name="tsm_shop_theme_update_options[input_theme_forest_api_key]" id="input_theme_forest_api_key" value="<?php echo esc_attr($options['input_theme_forest_api_key']); ?>" size="32" />
        
        <?php 
}



// 7. Validate settings
function tsm_shop_updates_validate_options( $input ) {
	
        if ( isset( $input['input_theme_forest_username'] ) ) { $input['input_theme_forest_username'] = wp_filter_nohtml_kses( trim( $input['input_theme_forest_username'] ) ); }
        if ( isset( $input['input_theme_forest_api_key'] ) ) { $input['input_theme_forest_api_key'] = wp_filter_nohtml_kses( trim( $input['input_theme_forest_api_key'] ) ); }
        
    return $input;
}



// 8. Miscellaneous functions



// To debug uncomment the following line:
// set_site_transient('update_themes',null);
function tsm_shop_themeforest_themes_update( $updates ) {
    if ( isset( $updates->checked ) ) {
        require_once( trailingslashit( get_template_directory() ) . "lib/updates/class-tsm-shop-themes-updater.php" );
        global $tsm_shop_theme_update_options;
        $username = $tsm_shop_theme_update_options['input_theme_forest_username'];
        $apikey = $tsm_shop_theme_update_options['input_theme_forest_api_key'];

        $envato_username = ( $username ) ? $username : null;
        $envato_api_key = ( $apikey ) ? $apikey : null;

        $updater = new tsm_shop_theme_Updater( $envato_username, $envato_api_key );
        $updates = $updater->check( $updates );
    }
    return $updates;
}
add_filter( 'pre_set_site_transient_update_themes', 'tsm_shop_themeforest_themes_update' );
    




function tsm_shop_alternative_update_methods_info() {
    ob_start(); ?>
            <div class="clear"></div>

            <h3 class="tsm-shop-updater-page-headers"><span class="dashicons dashicons-update"></span> <?php esc_html_e('ALTERNATIVE UPDATE METHODS', 'tsm_shop'); ?></h3>

            <h3><?php esc_html_e('Manual update:', 'tsm_shop'); ?></h3>
            <p><strong><?php esc_html_e('Please note:', 'tsm_shop'); ?></strong> <?php printf( esc_html__('It\'s always a great idea to make a backup of the theme\'s folder %s, or better yet, a full backup of your site including the database before proceeding with an update.', 'tsm_shop'),
                    '<strong>/wp-content/themes/tsm-shop/</strong>'); ?></p>
            <p><?php printf( esc_html__('First you need to download the latest version of the %1$sTSM-SHOP Theme%2$s, for that log into your %3$s account used to purchase the theme and from your %4$sDownloads%5$s section grab the theme\'s latest zip.', 'tsm_shop'),
                    '<a target="_blank" title="TSM-SHOP WordPress Premium Theme" href="#">', '</a>', 
                    '<a href="http://www.themeforest.net/" target="_blank">ThemeForest</a>', 
                    '<strong>', '</strong>' ); ?></p>
            <p><?php esc_html_e("Here's a couple of methods we usually recommend for updating the theme manually:", 'tsm_shop'); ?></p>
            <ul>
                <li><span class="dashicons dashicons-admin-tools" style="color:#696969;"></span> <strong><?php esc_html_e('Method 1:', 'tsm_shop'); ?></strong> <?php printf( esc_html__('You may simply drag-and-drop using your favorite FTP client the latest version of the theme (unzipped "tsm-shop" folder) over the existing ones in your web server. This will overwrite the current theme files with the new ones (example: %s). That way if you have uploaded any additional files to the theme\'s folder, they will not be deleted.', 'tsm_shop'),
                    '<a rel="nofollow" target="_blank" href="http://www.screenr.com/F7hs">http://www.screenr.com/F7hs</a>'); ?></li>
                <li><span class="dashicons dashicons-admin-tools" style="color:#696969;"></span> <strong><?php esc_html_e('Method 2:', 'tsm_shop'); ?></strong> <?php printf( esc_html__('Go to %s section, activate another theme temporarily which will de-activate the "TSM-SHOP" theme automatically. At this point go ahead and delete the "TSM-SHOP" theme (don\'t worry, you will not lose any of your themes\' options since those are saved in the database). Then upload, install and activate the latest version of the "TSM-SHOP" theme as if doing it for the first time.', 'tsm_shop'),
                    '<a title="Go to Appearance &rarr; Themes setion" href="' . admin_url() . 'themes.php" target="_blank">'.esc_html__('Appearance &rarr; Themes', 'tsm_shop').'</a>'); ?></li>
            </ul>
            <p><?php printf( esc_html__('If you have any caching plugins active or server side caching or %s don\'t forget to clear the cache.', 'tsm_shop'),
                    '<a href="http://en.wikipedia.org/wiki/Content_delivery_network" title="'.esc_html__('What is CDN?', 'tsm_shop').'" target="_blank">CDN</a>'); ?></p>
            <p><span class="dashicons dashicons-info" style="color:#696969;"></span> <?php printf( esc_html__('Now, %1$sif you have modified any core theme files in the past%2$s (those could be CSS, PHP, JS or ther files) but you haven\'t been keeping track of your changes then you can use some \'diff\' tools to locate exactly what was modified and thus be able to re-apply those changes after the update. For your reference, it\'s always better to use a "child" theme for customizations that way your changes will be safe with future updates of the "parent" theme, we offer a "child" theme for TSM-SHOP %3$sHERE%4$s.', 'tsm_shop'),
                    '<strong>', '</strong>',
                    '<a rel="nofollow" target="_blank" href="#">', '</a>' ); ?></p>
            <p><?php esc_html_e('For a full list of affected files in the latest release please refer to the theme\'s "Changelog".', 'tsm_shop'); ?></p>
            <p><?php printf( esc_html__('Should you have any questions regarding theme updates feel free to post in the %1$ssupport forum%2$s.', 'tsm_shop'),
                    '<a target="_blank" title="'.esc_html__('How do I update the theme!', 'tsm_shop').'" href="https://www.tonsamith.com/forum/?v=fd7030716334">', '</a>'); ?></p>
<?php
    echo ob_get_clean();
}
