<?php 
/**
 * @package WordPress
 * @subpackage TSM-SHOP
 */
if ( !defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $tsm_shop_options, $style, $current_slider, $tsm_shop_responsive;
// get the current color scheme subdirectory
$style = ( $tsm_shop_options['color_scheme'] ) ? "style{$tsm_shop_options['color_scheme']}": "style1";
$current_slider = $tsm_shop_options['current_slider'];
$tsm_shop_responsive = $tsm_shop_options['enable_responsive'];
$tsm_shop_responsive_body_class = ( $tsm_shop_responsive ) ? 'u-design-responsive-on' : '';
$tsm_shop_menu_auto_arrows = ( isset( $tsm_shop_options['show_menu_auto_arrows'] ) && $tsm_shop_options['show_menu_auto_arrows'] == 'yes' ) ? 'u-design-menu-auto-arrows-on' : '';
$tsm_shop_menu_drop_shadows = ( isset( $tsm_shop_options['show_menu_drop_shadows'] ) && $tsm_shop_options['show_menu_drop_shadows'] == 'yes' ) ? 'u-design-menu-drop-shadows-on' : '';
$tsm_shop_fixed_main_menu = ( $tsm_shop_options['fixed_main_menu'] ) ? 'tsm-shop-fixed-menu-on' : '';
$tsm_shop_responsive_pinch_to_zoom = ( $tsm_shop_options['responsive_pinch_to_zoom'] ) ? '' : ', maximum-scale=1.0';
set_theme_mod( 'tsm_shop_include_container', !tsm_shop_check_page_layout_option( 'no_container' ) ); // page specific layout options based on "U-Design Options" metabox selection

?>
<?php tsm_shop_html_before(); ?>
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>

<head profile="http://gmpg.org/xfn/11">
<?php tsm_shop_head_top(); ?>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<?php // add 'viewport' meta
if ( $tsm_shop_responsive ) echo '<meta name="viewport" content="width=device-width, initial-scale=1.0'.$tsm_shop_responsive_pinch_to_zoom.'" />'; ?>

<?php wp_head(); ?>

<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>

<?php // Load only if less than WordPress 4.2, if newer it's loaded in functions.php with 'wp_script_add_data' for the IE condisionals
global $wp_version;
if ( version_compare( $wp_version, '4.2.0', '<' ) ) : ?>
<!--[if lt IE 9]>
    <script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() ); ?>/scripts/respond.min.js"></script>
<![endif]-->
<?php endif; ?>

<?php echo $tsm_shop_options['google_analytics']; ?>
<?php tsm_shop_head_bottom(); ?>
</head>
<body  <?php tsm_shop_inside_body_tag(); ?> <?php body_class( array ($tsm_shop_responsive_body_class, $tsm_shop_menu_auto_arrows, $tsm_shop_menu_drop_shadows, $tsm_shop_fixed_main_menu) ); ?>>
<?php tsm_shop_body_top(); ?>
    
    <div id="wrapper-1">
<?php   tsm_shop_top_wrapper_before(); ?>
<?php   $tsm_shop_include_header = !tsm_shop_check_page_layout_option( 'no_header' );
        if( $tsm_shop_include_header ) : ?>
            <div id="top-wrapper">
<?php           tsm_shop_top_wrapper_top(); ?>
                <div id="top-elements" class="container_24">
<?php               tsm_shop_top_elements_inside( is_front_page() ); ?>
                </div>
                <!-- end top-elements -->
<?php           tsm_shop_top_wrapper_bottom( is_front_page() ); ?>
            </div>
            <!-- end top-wrapper -->
<?php   endif; ?>
	<div class="clear"></div>
        
<?php   tsm_shop_top_wrapper_after( is_front_page() ); ?>

<?php	if( is_front_page() ) : 
    
            tsm_shop_front_page_slider_before();

	    if( $current_slider == '1' ) :
		// flashmo grid slider has been removed from the theme and no longer available
	    elseif( $current_slider == '2' ) :
		// Piecemaker slider has been removed from the theme and no longer available
	    elseif( $current_slider == '3' ) :
		// Piecemaker 2 slider has been removed from the theme and no longer available
	    elseif ( $current_slider == '4' ) :
		include( trailingslashit( get_template_directory() ) . 'sliders/cycle/cycle1/cycle1_display.php' );
	    elseif ( $current_slider == '5' ) :
		include( trailingslashit( get_template_directory() ) . 'sliders/cycle/cycle2/cycle2_display.php' );
	    elseif ( $current_slider == '6' ) :
		include( trailingslashit( get_template_directory() ) . 'sliders/cycle/cycle3/cycle3_display.php' );
	    elseif ( $current_slider == '8' ) : ?>
		<div id="rev-slider-header">
<?php               // Load Revolution slider
                    if ( class_exists('RevSliderFront') && $tsm_shop_options['rev_slider_shortcode'] ) {
                        $rvslider = new RevSlider();
                        $arrSliders = $rvslider->getArrSliders();
                        if( !empty( $arrSliders ) ) {
                            echo do_shortcode( $tsm_shop_options['rev_slider_shortcode'] );
                        }
                    } ?>
		</div>
		<!-- end rev-slider-header -->
<?php	    elseif ( $current_slider == '7' ) : // no slider ?>
		<div id="page-content-title">
		    <div id="page-content-header" class="container_24">
			<div id="page-title">
<?php                       if ( $tsm_shop_options['no_slider_text'] ) echo '<h2>' . $tsm_shop_options['no_slider_text'] . '</h2>'; ?>
			</div>
		    </div>
		    <!-- end page-content-header -->
		</div>
		<!-- end page-content-title -->
<?php	    endif; ?>
                
<?php       tsm_shop_front_page_slider_after(); ?>

	    <div class="clear"></div>
<?php


            // home-page-before-content Widget Area
            $before_cont_1_is_active = sidebar_exist_and_active('home-page-before-content');
            if ( $before_cont_1_is_active  ) : // hide this area if no widgets are active...
?>
                <div id="before-content">
                    <div id="before-content-column" class="container_24">
                        <div class="home-page-divider"></div>
<?php
                        if ( $before_cont_1_is_active ) {
                            echo get_dynamic_column( 'before-cont-box-1', 'column_3_of_3 home-cont-box', 'home-page-before-content' );
                        } ?>
                        <div class="home-page-divider"></div>
                    </div>
                    <!-- end before-content-column -->
                </div>
                <!-- end before-content -->

		<div class="clear"></div>

<?php	    endif; ?>

<?php       tsm_shop_home_page_content_before(); ?>
	    <div id="home-page-content">
<?php           tsm_shop_home_page_content_top(); ?>

<?php	else : // NOT front page ?>

<?php       tsm_shop_page_content_before(); ?>
	    <div id="page-content">
<?php           tsm_shop_page_content_top(); // this hook is used to insert the breadcrumbs ?>

<?php	endif;




