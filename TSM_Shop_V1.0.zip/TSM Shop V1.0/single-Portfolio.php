<?php
/**
 * @package WordPress
 * @subpackage TSM-SHOP
 */
if ( !defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

    get_header();

    $content_position = ( $tsm_shop_options['portfolio_sidebar'] == 'left' ) ? 'grid_16 push_8' : 'grid_16';
    if ( $tsm_shop_options['remove_single_portfolio_sidebar'] == 'yes' ) $content_position = 'grid_24';
?>
    <div id="content-container" class="container_24">
	<div id="main-content" class="<?php echo $content_position; ?>">
	    <div class="main-content-padding">
<?php           tsm_shop_main_content_top( is_front_page() ); ?>
<?php           if (have_posts()) :
                    while (have_posts()) : the_post(); ?>
                        <div <?php post_class(); ?> id="post-<?php the_ID();?>">
<?php                       tsm_shop_single_portfolio_entry_before(); ?>
                            <div class="entry">
<?php                           tsm_shop_single_portfolio_entry_top(); ?>
                                
<?php                           the_content(__('<p class="serif">Read the rest of this entry &raquo;</p>', 'tsm_shop')); ?>
                                
<?php                           tsm_shop_single_portfolio_entry_bottom(); ?>
                            </div>
<?php                       tsm_shop_single_portfolio_entry_after(); ?>
                        </div>

<?php                   if( $tsm_shop_options['show_portfolio_comments'] == 'yes' ) {
                            comments_template();
                        }
		    
                    endwhile; else: ?>
		    <p><?php esc_html_e("Sorry, no posts matched your criteria.", 'tsm_shop'); ?></p>
<?php           endif; ?>

<?php           tsm_shop_main_content_bottom(); ?>
	    </div><!-- end main-content-padding -->
	</div><!-- end main-content -->
<?php
	if( ( !$tsm_shop_options['remove_single_portfolio_sidebar'] == 'yes' ) && sidebar_exist('PortfolioSidebar') ) { get_sidebar('PortfolioSidebar'); }
?>
    </div><!-- end content-container -->



